<?php
  session_start();
    //$connect=mysql_connect("localhost","root","");
    //$db=mysql_select_db("wt",$connect) or die("could not conect");
       $us=$_REQUEST["username"];
       $pw=$_REQUEST["password"];
         if(isset($_REQUEST['Login']))
         {
           // $q="select username,password from login where username='$us';";
            //$val=mysql_query($q);
            if(mysql_num_rows($val)==0)
            {
               echo "dont have an account,please signup";
               header ('Location:signup.html');
            }
            else  
            {
               $row=mysql_fetch_array($val);
              if($pw==$row['password'])
                echo "Succesful login";
              else
              {
                  $_SESSION['x']="wrong password";
                  header ('Location:login.php');
              }
            } 
          }
//mysql_close($connect);
?>
