<?php
  if(isset($_REQUEST["signup"]))
  {
     header ('Location:signup.html');
  }
  if(isset($_REQUEST["login"]))
  {
     header ('Location:login.php');
  }
?>