<html>
<form method="post" action="prathyush.php">
<input type="text" placeholder="Full Name" name="name" required/><br>
                
                <input type="text"  name="yr" required/><br>
				
				<input type="text" placeholder="Address" name="rn" required/><br>
				<input type="text" placeholder="Contact no" name="dept" required/><br>
                <input type="submit" name="submit" value="submit"/>
				</form>
</html>