<?php
	$conn=mysqli_connect("localhost","root","") or die("could not find conn");
	$db=mysqli_select_db($conn,"prathyush") or die("could not find db");
	$r=$_REQUEST["rn"];
	$n=$_REQUEST["name"];
	$yr=$_REQUEST["yr"];
	$dept=$_REQUEST["dept"];
	echo "insert values";
	$i="insert into room values ('$r','$n','$yr','$dept',0,0);";
	mysqli_query($conn,$i);
	$s="select * from room where rn='$r';";
	$s1="select * from count;";
	mysqli_query($conn,$s1);
	$row=mysqli_fetch_array($s1,MYSQLI_BOTH);
	if($dept=="IT" && $yr==2)
	{
		if($row["IT2"]<=50)
		{
		    $row["IT2"]++;
			$q=$row["IT2"];
			echo $q;
			$w="update count set IT2='$q';";
			mysqli_query($conn,$w);
			$room=200+$q;
			$e="update room set room='$room';";
			mysqli_query($conn,$e);
			echo "room allocated...$room";
		}
	}
	
?>